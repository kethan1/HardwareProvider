This package finds info about the hardware. 

The github page is: https://github.com/kethan1/HardwareProvider.

The pypi page is: https://pypi.org/project/HardwareProvider/